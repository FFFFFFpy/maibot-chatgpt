"""Public SIWC protocol. No SDK/browser session files and no client secret."""

import asyncio
import base64
import hashlib
import hmac
import json
import secrets
import socket
import ssl
import time
from urllib.parse import parse_qs, urlencode, urlsplit
import webbrowser

import httpx
import jwt

from .credentials import DIRECT, ISSUER, pause_clear, stamp
from .errors import Error

from .oauth_constants import RESOURCE
from .wire import private_wire, network_client

DISCOVERY = ISSUER + "/.well-known/openid-configuration"
AUTHORIZE = ISSUER + "/api/accounts/authorize"
TOKEN = ISSUER + "/api/accounts/oauth/token"
REVOKE = ISSUER + "/api/accounts/oauth/revoke"
JWKS = ISSUER + "/.well-known/jwks.json"
APP = "MaiBot ChatGPT Subscription Provider"
DYNAMIC = "dynamic_agent_client"
SCOPES = "openid profile email offline_access resource.invoke " + DIRECT
TERMINAL = {
    "invalid_grant",
    "invalid_refresh_token",
    "token_expired",
    "refresh_token_expired",
    "refresh_token_invalidated",
    "refresh_token_reused",
}


def text(v):
    return isinstance(v, str) and bool(v.strip())


def discovery_error(category, detail, status=None):
    err = Error(category, status=status)
    err.hint = "Runner 请求 auth.openai.com 的登录配置失败：" + detail
    err.args = (f"[chatgpt_subscription:{category}] {err.hint}",)
    return err


def discovery_transport(exc):
    # Never surface exception text, response bodies, proxy URLs or headers.
    cause = exc
    for _ in range(12):
        if isinstance(cause, ssl.SSLCertVerificationError):
            return discovery_error(
                "transport",
                "TLS 证书校验未通过。请检查容器时间、受信 CA 和 SSL_CERT_FILE；不要关闭验证。",
            )
        if isinstance(cause, ssl.SSLError):
            return discovery_error(
                "transport", "TLS 握手失败。请检查 Runner 出站代理及 TLS 配置。"
            )
        if isinstance(cause, socket.gaierror):
            return discovery_error(
                "transport", "DNS 解析失败。请检查容器能否解析目标或所配置的代理主机。"
            )
        cause = cause.__cause__ or cause.__context__
        if cause is None:
            break
    if isinstance(exc, httpx.ProxyError):
        return discovery_error(
            "transport",
            "代理连接或认证失败。请检查 Runner 的 HTTPS_PROXY / ALL_PROXY。",
        )
    if isinstance(exc, httpx.TimeoutException):
        return discovery_error(
            "transport", "请求超时。请检查容器的出口、防火墙和代理是否可达。"
        )
    return discovery_error(
        "transport",
        "未建立或未完成连接。请检查容器到目标的 443 出口、DNS 和代理；桌面浏览器可访问不代表 Runner 可访问。",
    )


class OAuth:
    def __init__(self, transport=None, timeout=20):
        self.transport = transport
        self.timeout = timeout

    def http(self, method, url, *, form=None, deadline=None, refresh=False):
        if (method, url) not in {
            ("GET", DISCOVERY),
            ("GET", JWKS),
            ("POST", TOKEN),
            ("POST", REVOKE),
        }:
            raise Error("route_mismatch")
        deadline = deadline or time.monotonic() + self.timeout
        left = deadline - time.monotonic()
        if left <= 0:
            raise Error("transport")
        try:
            with (
                private_wire(),
                network_client(
                    httpx.Client,
                    "auth.openai.com",
                    transport=self.transport,
                    timeout=left,
                ) as client,
            ):
                with client.stream(method, url, data=form) as r:
                    buf = bytearray()
                    status = r.status_code
                    if url == DISCOVERY and status != 200:
                        raise discovery_error(
                            "upstream",
                            f"收到 HTTP {status}，未取得登录配置。请检查出口代理或目标服务是否拒绝请求。",
                            status,
                        )
                    for chunk in r.iter_bytes():
                        if time.monotonic() > deadline:
                            raise httpx.ReadTimeout("deadline exceeded")
                        if len(buf) + len(chunk) > 2**20:
                            raise ValueError
                        buf.extend(chunk)
            if url == REVOKE and status == 200:
                return {}
            obj = json.loads(buf)
            if not isinstance(obj, dict):
                raise ValueError
            if status == 200:
                return obj
            code = obj.get("error")
            code = code.get("code") if isinstance(code, dict) else code
            if isinstance(code, str) and code in TERMINAL and refresh:
                raise Error("auth_required")
            if code == "invalid_client":
                raise Error("invalid_client")
            category = "upstream" if not refresh else "refresh_uncertain"
        except Error as exc:
            if url != DISCOVERY or exc.category != "invalid_config":
                raise
            failure = discovery_error(
                "invalid_config",
                "Runner 的代理或 CA 配置无法加载。请检查代理协议及 CA 文件路径。",
            )
        except httpx.HTTPError as exc:
            if url == DISCOVERY:
                failure = discovery_transport(exc)
            else:
                before_send = isinstance(
                    exc, (httpx.ConnectError, httpx.ConnectTimeout, httpx.PoolTimeout)
                )
                failure = Error(
                    "refresh_uncertain" if refresh and not before_send else "transport"
                )
        except (ValueError, RecursionError):
            failure = (
                discovery_error(
                    "upstream",
                    "返回的不是有效的登录配置，或响应超限。请检查代理是否返回了拦截页。",
                )
                if url == DISCOVERY
                else Error("refresh_uncertain" if refresh else "transport")
            )
        else:
            failure = Error(category)
        raise failure

    def discover(self):
        doc = self.http("GET", DISCOVERY)
        for key, url in [
            ("issuer", ISSUER),
            ("authorization_endpoint", AUTHORIZE),
            ("token_endpoint", TOKEN),
            ("jwks_uri", JWKS),
        ]:
            if doc.get(key) != url:
                raise Error("route_mismatch")
        return doc

    def revoke(self, d):
        if self.discover().get("revocation_endpoint") != REVOKE:
            raise Error("route_mismatch")
        form = dict(
            token=d["tokens"]["refresh_token"],
            token_type_hint="refresh_token",
            client_id=d["registration"]["client_id"],
        )
        for i in range(2):
            try:
                self.http("POST", REVOKE, form=form)
                return
            except Error as e:
                if i or e.category not in ("upstream", "transport"):
                    raise

    def verify(self, token, client, keys, nonce=None, deadline=None):
        try:
            head = jwt.get_unverified_header(token)
            kid = head["kid"]
            if not text(kid) or head.get("alg") != "RS256":
                raise ValueError

            def select(jwks):
                return [
                    k
                    for k in jwks.get("keys", [])
                    if isinstance(k, dict)
                    and k.get("kid") == kid
                    and k.get("kty") == "RSA"
                    and k.get("use", "sig") == "sig"
                    and k.get("alg", "RS256") == "RS256"
                ]

            selected = select(keys)
            if not selected:
                keys = self.http("GET", JWKS, deadline=deadline)
                selected = select(keys)
            if len(selected) != 1:
                raise ValueError
            key = jwt.PyJWK.from_dict(selected[0], algorithm="RS256").key
            claims = jwt.decode(
                token,
                key,
                algorithms=["RS256"],
                issuer=ISSUER,
                audience=client,
                leeway=5,
                options={"require": ["sub", "iss", "aud", "exp", "iat"]},
            )
            if not text(claims["sub"]):
                raise ValueError
            aud = claims["aud"]
            azp = claims.get("azp")
            if (
                azp is not None or isinstance(aud, list) and len(aud) > 1
            ) and azp != client:
                raise ValueError
            if nonce is not None and not hmac.compare_digest(
                nonce, claims.get("nonce", "")
            ):
                raise ValueError
            return claims, keys
        except (
            jwt.PyJWTError,
            ValueError,
            KeyError,
            TypeError,
            AttributeError,
            OverflowError,
        ):
            pass
        raise Error("invalid_login")

    def record(self, obj, client, *, old=None, nonce=None, deadline=None):
        # On refresh, omitted scope and refresh_token retain their previous grants/values.
        prior = old["tokens"] if old else {}
        keys = old.get("jwks", {}) if old else {}
        access = obj.get("access_token")
        refresh = obj.get("refresh_token", prior.get("refresh_token"))
        ttl = obj.get("expires_in")
        if (
            not text(access)
            or not text(refresh)
            or str(obj.get("token_type", "")).lower() != "bearer"
            or type(ttl) is not int
            or not 0 < ttl <= 315360000
        ):
            raise Error("invalid_login")
        scopes = obj.get("scope", " ".join(old["granted_scopes"]) if old else "")
        if not isinstance(scopes, str):
            raise Error("invalid_login")
        reg = old["registration"] if old else None
        id_token = obj.get("id_token", prior.get("id_token"))
        if not old or "id_token" in obj:
            claims, keys = self.verify(id_token, client, keys, nonce, deadline)
            if reg and claims["sub"] != reg["subject"]:
                raise Error("registration_mismatch")
            reg = dict(
                issuer=ISSUER,
                subject=claims["sub"],
                client_id=client,
                display_label="acct-"
                + hashlib.sha256(claims["sub"].encode()).hexdigest()[:8],
            )
            email = claims.get("email")
            if (
                claims.get("email_verified") is True
                and isinstance(email, str)
                and 3 <= len(email) <= 254
                and "@" in email
                and email.isprintable()
            ):
                reg["display_label"] = email
            elif old:
                reg["display_label"] = old["registration"].get(
                    "display_label", reg["display_label"]
                )
        now = time.time()
        granted = scopes.split()
        return dict(
            schema_version=1,
            registration=reg,
            revision=old["revision"] if old else 0,
            session_generation=old["session_generation"] if old else 0,
            state="active" if DIRECT in granted else "missing_direct_scope",
            tokens=dict(
                token_type="Bearer",
                access_token=access,
                refresh_token=refresh,
                id_token=id_token,
            ),
            granted_scopes=granted,
            received_at=stamp(now),
            expires_at=stamp(now + ttl),
            earliest_refresh_at=obj.get("earliest_refresh_at"),
            jwks=keys,
            pause=old["pause"] if old else pause_clear(),
        )

    def refresh(self, d):
        deadline = time.monotonic() + self.timeout
        client = d["registration"]["client_id"]
        obj = self.http(
            "POST",
            TOKEN,
            form=dict(
                grant_type="refresh_token",
                client_id=client,
                refresh_token=d["tokens"]["refresh_token"],
                resource=RESOURCE,
            ),
            deadline=deadline,
            refresh=True,
        )
        try:
            return self.record(obj, client, old=d, deadline=deadline)
        except Error:
            pass
        raise Error("refresh_uncertain")


def pkce_material():
    state, nonce, verifier = (secrets.token_urlsafe(48) for _ in range(3))
    challenge = (
        base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest())
        .decode()
        .rstrip("=")
    )
    return state, nonce, verifier, challenge


def authorize_url(host, client, old, state, nonce, challenge, redirect):
    params = dict(
        client_id=client,
        ext_agent_host_id=host,
        response_type="code",
        scope=SCOPES,
        resource=RESOURCE,
        redirect_uri=redirect,
        state=state,
        nonce=nonce,
        code_challenge=challenge,
        code_challenge_method="S256",
    )
    if client == DYNAMIC:
        params["agent_name_hint"] = APP
    if old and old["state"] in (
        "missing_direct_scope",
        "auth_required",
        "refresh_uncertain",
    ):
        params["prompt"] = "consent"
    return AUTHORIZE + "?" + urlencode(params)


def callback_pair(args, client):
    issued = args.get("client_id", [None if client == DYNAMIC else client])
    codes = args.get("code", [])
    if (
        "error" in args
        or len(codes) != 1
        or not text(codes[0])
        or len(issued) != 1
        or not text(issued[0])
        or issued[0] == DYNAMIC
        or client not in (DYNAMIC, issued[0])
    ):
        return None
    return issued[0], codes[0]


async def exchange(store, oauth, generation, issued, code, verifier, redirect, nonce):
    obj = await asyncio.to_thread(
        oauth.http,
        "POST",
        TOKEN,
        form=dict(
            grant_type="authorization_code",
            resource=RESOURCE,
            client_id=issued,
            code=code,
            code_verifier=verifier,
            redirect_uri=redirect,
        ),
    )
    d = await asyncio.to_thread(oauth.record, obj, issued, nonce=nonce)
    await asyncio.to_thread(store.replace, d, generation)
    if d["state"] != "active":
        raise Error("permission_denied")


async def login(
    store,
    oauth,
    opener=webbrowser.open,
    timeout=180,
    *,
    port=0,
    page_ready=None,
    on_exchange=None,
):
    host, old = await asyncio.to_thread(store.begin)
    generation = old["session_generation"] if old else 0
    client = old["registration"]["client_id"] if old else DYNAMIC
    await asyncio.to_thread(oauth.discover)
    state, nonce, verifier, challenge = pkce_material()
    loop = asyncio.get_running_loop()
    answer = loop.create_future()
    handlers = set()

    # Both the local listener and the authenticated page action use this one-shot gate.
    def accept_url(raw):
        if answer.done() or not isinstance(raw, str) or not 1 <= len(raw) <= 12000:
            return False
        if not raw.isascii() or any(ord(c) < 33 or ord(c) == 127 for c in raw):
            return False
        if raw.partition("?")[0] != redirect or "#" in raw:
            return False
        try:
            args = parse_qs(
                raw.partition("?")[2],
                keep_blank_values=True,
                max_num_fields=20,
                strict_parsing=True,
            )
            if len(args.get("state", [])) != 1 or not hmac.compare_digest(
                args["state"][0], state
            ):
                return False
            pair = callback_pair(args, client)
        except (TypeError, ValueError):
            return False
        if not pair and "error" not in args:
            return False
        answer.set_result(pair)
        if on_exchange:
            on_exchange()
        return True

    async def callback(reader, writer):
        job = asyncio.current_task()
        handlers.add(job)
        ok = False
        try:
            raw = await asyncio.wait_for(reader.readuntil(b"\r\n\r\n"), 4)
            method, target, _ = raw.split(b"\r\n", 1)[0].decode("ascii").split(" ")
            u = urlsplit(target)
            if (
                method != "GET"
                or u.path != "/auth/callback"
                or u.netloc
                or u.scheme
                or answer.done()
            ):
                return
            if page_ready is not None:
                hosts = [
                    v.strip()
                    for line in raw.split(b"\r\n")[1:]
                    for k, sep, v in [line.partition(b":")]
                    if sep and k.lower() == b"host"
                ]
                if hosts != [urlsplit(redirect).netloc.encode("ascii")]:
                    return
                ok = (
                    accept_url(redirect + "?" + u.query)
                    if target.startswith("/auth/callback?") and "#" not in target
                    else False
                )
                return
            args = parse_qs(u.query, keep_blank_values=True, max_num_fields=20)
            if len(args.get("state", [])) != 1 or not hmac.compare_digest(
                args["state"][0], state
            ):
                answer.set_result(None)
                return
            pair = callback_pair(args, client)
            answer.set_result(pair)
            if pair is None:
                return
            ok = True
        except (
            ValueError,
            UnicodeError,
            TimeoutError,
            asyncio.IncompleteReadError,
            asyncio.LimitOverrunError,
            ConnectionError,
        ):
            pass
        finally:
            try:
                body = (
                    "已收到登录返回地址。请关闭此标签页，回到 MaiBot 查看结果。"
                    if ok
                    else "这个登录地址无效或已过期，请回到 MaiBot 重新开始。"
                ).encode()
                writer.write(
                    b"HTTP/1.1 "
                    + (b"200 OK" if ok else b"400 Bad Request")
                    + b"\r\nContent-Type: text/plain; charset=utf-8\r\nConnection: close\r\nCache-Control: no-store\r\nReferrer-Policy: no-referrer\r\n\r\n"
                    + body
                )
                await writer.drain()
            except (ConnectionError, OSError):
                pass
            finally:
                writer.close()
                handlers.discard(job)

    server = await asyncio.start_server(callback, "127.0.0.1", port, limit=16384)
    redirect = f"http://127.0.0.1:{server.sockets[0].getsockname()[1]}/auth/callback"
    url = authorize_url(host, client, old, state, nonce, challenge, redirect)
    try:
        async with asyncio.timeout(timeout):
            if page_ready is not None:
                page_ready(url, accept_url)
            elif await asyncio.to_thread(opener, url) is False:
                raise Error("invalid_login")
            pair = await answer
    except TimeoutError:
        pair = None
    finally:
        server.close()
        await server.wait_closed()
        jobs = list(handlers)
        for task in jobs:
            task.cancel()
        await asyncio.gather(*jobs, return_exceptions=True)
    if not pair:
        raise Error("invalid_login")
    issued, code = pair
    await exchange(store, oauth, generation, issued, code, verifier, redirect, nonce)
